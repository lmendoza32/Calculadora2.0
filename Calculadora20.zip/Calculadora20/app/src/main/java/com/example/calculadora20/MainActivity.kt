package com.example.calculadora20

import androidx.appcompat.app.AppCompatActivity
import android.os.Bundle
import android.view.View
import android.widget.EditText
import android.widget.RadioButton
import android.widget.TextView

class MainActivity : AppCompatActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_main)
        var et1 = findViewById<View>(R.id.eTextValor1) as EditText
        var et2 = findViewById<View>(R.id.eTextValor2) as EditText
        var res = findViewById<View>(R.id.tViewResultado) as TextView
        var sum = findViewById<View>(R.id.rButtonSuma) as RadioButton
        var rest = findViewById<View>(R.id.rButtonResta) as RadioButton
        var btn = findViewById<View>(R.id.btnResultado) as TextView

        btn.setOnClickListener {
            if(sum.isChecked()==true)
            {
                var resultado = et1.text.toString().toInt() + et2.text.toString().toInt()
                res.text = "El resultado es: "+ resultado
            }else if(rest.isChecked==true)
            {
                var resultado = et1.text.toString().toInt() - et2.text.toString().toInt()
                res.text = "El resultado es: "+ resultado
            }
        }
    }
}